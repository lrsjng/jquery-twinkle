# jQuery.twinkle

* Website with download, docs and demo: <http://larsjung.de/twinkle>
* Sources: <http://github.com/lrsjng/jQuery.twinkle>

jQuery.twinkle is provided under the terms of the [MIT License](http://github.com/lrsjng/jQuery.twinkle/blob/master/LICENSE.txt).  


## Changelog

### v0.1 · *2011-08-08*

